//
//  RightCognitiveAndLanguageDashboardViewController.h
//  My First Steps
//
//  Created by Blake Harrison on 12/12/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "CognitiveAndLanguageDashboardViewController.h"

@interface RightCognitiveAndLanguageDashboardViewController : CognitiveAndLanguageDashboardViewController
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UIButton *homeButton;
@property (weak, nonatomic) IBOutlet UIButton *tabButton;
@property (weak, nonatomic) IBOutlet UIButton *rightScrollButton;

@end
