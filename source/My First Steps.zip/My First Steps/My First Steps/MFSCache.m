//
//  DCSSharedCache.m
//  DCSMedicalApps
//
//  Created by Blake Harrison on 10/11/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "MFSCache.h"

@implementation MFSCache
static MFSCache *sharedCache = nil; // Static instance of the singleton

/* This method returns a shared instance of the MAMSharedResources class */
+(id)sharedCache
{
    @synchronized(self)
    {
        if(!sharedCache)
        {
            srand48(arc4random());
            sharedCache = [[MFSCache alloc]init];
        }
    }
    
    return sharedCache;
}

-(id)init{
    if(self = [super init]){
              self.currentIndex = @(-1);
    }
    
    return self;
}
@end
