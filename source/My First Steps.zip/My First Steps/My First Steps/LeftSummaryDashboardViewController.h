//
//  LeftSummaryDashboardViewController.h
//  My First Steps
//
//  Created by Blake Harrison on 12/12/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "SummaryDashboardViewController.h"

@interface LeftSummaryDashboardViewController : SummaryDashboardViewController
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UIButton *homeButton;
@property (weak, nonatomic) IBOutlet UIButton *leftScrollButton;
@property (weak, nonatomic) IBOutlet UIButton *tabButton;
@end
