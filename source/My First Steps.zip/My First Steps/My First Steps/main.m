//
//  main.m
//  My First Steps
//
//  Created by Blake Harrison on 12/9/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
