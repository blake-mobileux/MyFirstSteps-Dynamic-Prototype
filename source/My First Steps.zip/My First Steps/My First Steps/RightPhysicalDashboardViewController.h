//
//  RightPhysicalDashboardViewController.h
//  My First Steps
//
//  Created by Blake Harrison on 12/12/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "PhysicalDashboardViewController.h"

@interface RightPhysicalDashboardViewController : PhysicalDashboardViewController
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UIButton *homeButton;
@property (weak, nonatomic) IBOutlet UIButton *rightScrollButton;
@property (weak, nonatomic) IBOutlet UIButton *tabButton;

@end
