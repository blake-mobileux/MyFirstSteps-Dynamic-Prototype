//
//  LeftPhysicalDashboardViewController.m
//  My First Steps
//
//  Created by Blake Harrison on 12/12/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "LeftPhysicalDashboardViewController.h"

@interface LeftPhysicalDashboardViewController ()

@end

@implementation LeftPhysicalDashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.backButton setAlpha:.5f];
    [self.backButton setEnabled:false];
    
    [self.homeButton setAlpha:.5f];
    [self.homeButton setEnabled:false];
    
    [self.leftScrollButton setAlpha:.5f];
    [self.leftScrollButton setEnabled:false];
    
    [self.tabButton setEnabled:false];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
