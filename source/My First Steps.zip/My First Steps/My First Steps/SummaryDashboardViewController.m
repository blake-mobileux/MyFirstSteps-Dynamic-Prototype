//
//  ViewController.m
//  My First Steps
//
//  Created by Blake Harrison on 12/9/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "SummaryDashboardViewController.h"

@interface SummaryDashboardViewController ()

@end

@implementation SummaryDashboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
-(BOOL)prefersStatusBarHidden{
    return YES;
}
 */

@end
