//
//  DCSSharedCache.h
//  DCSMedicalApps
//
//  Created by Blake Harrison on 10/11/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MFSVizualization.h"

@interface MFSCache : NSObject
@property (nonatomic, strong)MFSVizualization *vizs;
@property (nonatomic, strong)NSNumber *currentIndex;
+ (id)sharedCache;
-(id)init;
@end
