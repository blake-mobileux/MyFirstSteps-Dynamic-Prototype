//
//  AddNewTopicPostViewController.h
//  My First Steps
//
//  Created by Blake Harrison on 12/13/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddNewTopicPostViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *titleTextBox;
@property (weak, nonatomic) IBOutlet UITextField *existingCatagoryTextBox;
@property (weak, nonatomic) IBOutlet UITextView *detailedDescription;
@end
