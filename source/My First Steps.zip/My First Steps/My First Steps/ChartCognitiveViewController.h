//
//  ChartCognitiveViewController.h
//  My First Steps
//
//  Created by Blake Harrison on 12/13/15.
//  Copyright © 2015 H451 Interaction Design. All rights reserved.
//

#import "CognitiveAndLanguageDashboardViewController.h"

@interface ChartCognitiveViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *backButton;

@end
